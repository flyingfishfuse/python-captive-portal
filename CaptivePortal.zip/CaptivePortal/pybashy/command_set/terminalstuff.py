# tmux new session
tmux new -s mysession -n mywindow
