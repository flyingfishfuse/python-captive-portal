# -*- coding: utf-8 -*-
################################################################################
##			debootstrapy - a linux tool for using debootstrap				  ##
################################################################################
# Copyright (c) 2020 Adam Galindo											  ##
#																			  ##
# Permission is hereby granted, free of charge, to any person obtaining a copy##
# of this software and associated documentation files (the "Software"),to deal##
# in the Software without restriction, including without limitation the rights##
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell   ##
# copies of the Software, and to permit persons to whom the Software is		  ##
# furnished to do so, subject to the following conditions:					  ##
#																			  ##
# Licenced under GPLv3														  ##
# https://www.gnu.org/licenses/gpl-3.0.en.html								  ##
#																			  ##
# The above copyright notice and this permission notice shall be included in  ##
# all copies or substantial portions of the Software.						  ##
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
####
################################################################################
"""


"""
__author__ 	= 'Adam Galindo'
__email__ 	= 'null@null.com'
__version__ = '1'
__license__ = 'GPLv3'

from pybashy.useful_functions import greenprint,yellow_bold_print,redprint
from pybashy.useful_functions import info_message,warning_message,critical_message
from pybashy.useful_functions import error_message

class CommandSet():
    '''
    Basic structure of the command set execution pool
    This is essentially the file/module loaded into a Class
        - All the stuff at the top level of the scope 
            - defs as thier name
            - variables as thier name
            - everything is considered an individual command 
              unless it matches a keyword like "steps"
                - Those commands are turned into Command() 's 
    
        - feed it kwargs
    
        - put it in the execution pool
    
        - then feed it to the STEPPER
    '''
    #def __new__(cls, clsname, bases, clsdict):
    #    return super().__new__(cls, clsname, bases, clsdict)
    def __init__(self, kwargs):
        self.steps         = dict
        self.command_list = []
        #if key in basic_items or (key.startswith('function')):
        #self.command_list.append(Command(**kwargs))

    #def assign_steps(kwargs):
        #'''

        #'''
        #for key, value in kwargs:


    def run_command(self, command):
        '''

        '''
        for key, value in self.steps.items():
            if key == command:
                print(key,value)
                Command(command)

    def error_exit(self, message : str, derp):
        #error_message(message = message)
        print(derp.with_traceback)
        #sys.exit()    
    
    def add_command(self, kwargs):
        '''
This is a future method to add commands from the terminal
        '''
