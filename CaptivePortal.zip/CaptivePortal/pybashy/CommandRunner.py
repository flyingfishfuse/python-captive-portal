# -*- coding: utf-8 -*-
################################################################################
##			debootstrapy - a linux tool for using debootstrap				  ##
################################################################################
# Copyright (c) 2020 Adam Galindo											  ##
#																			  ##
# Permission is hereby granted, free of charge, to any person obtaining a copy##
# of this software and associated documentation files (the "Software"),to deal##
# in the Software without restriction, including without limitation the rights##
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell   ##
# copies of the Software, and to permit persons to whom the Software is		  ##
# furnished to do so, subject to the following conditions:					  ##
#																			  ##
# Licenced under GPLv3														  ##
# https://www.gnu.org/licenses/gpl-3.0.en.html								  ##
#																			  ##
# The above copyright notice and this permission notice shall be included in  ##
# all copies or substantial portions of the Software.						  ##
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
####
################################################################################
"""
second level file, calls the CommandSet() and Command() Classes

"""
__author__ 	= 'Adam Galindo'
__email__ 	= 'null@null.com'
__version__ = '1'
__license__ = 'GPLv3'

import os
import sys
import pkgutil
import threading
import subprocess
from pathlib import Path
from importlib import import_module
from pybashy.useful_functions import greenprint,yellow_bold_print,redprint
from pybashy.useful_functions import info_message,warning_message,critical_message
from pybashy.useful_functions import error_message

from pybashy.Command import Command

class CommandRunner:
    '''
NARF!
Goes running after commands
    '''
    def __init__(self,kwargs):
        for (k, v) in kwargs.items():
            setattr(self, k, v)

    def error_exit(self, message : str, derp : Exception):
        error_message(message = message)
        print(derp.with_traceback)
        sys.exit()    

    def list_modules(self):
        '''
    Lists modules in command_set directory
        '''
        list_of_modules = []
        command_files_dir = os.path.dirname(__file__) + "/command_set"        
        list_of_subfiles  = pkgutil.iter_modules([command_files_dir])
        for x in list_of_subfiles:
            print(x.name)
            list_of_modules.append(x.name)
        return list_of_modules
    
	# return functions from loaded modules
    def get_functions(self, file_import):
        kwargs                 = {}
        kwargs_functions       = {}
        command_pool           = {}
        try:
			#sort through the items
            for thing_name in dir(file_import):
				# remove internal things
                if thing_name.startswith('__') != True:
					#focus on functions
                    if thing_name.startswith('function'):
                        function_internals = getattr(file_import, thing_name)
                        kwargs_functions[thing_name] = function_internals
					#sorting through top level item in the file/module
					# the stuff in "basic items" that are likley supposed to run first
                    else:
						if thing_name in Command.basic_items:
                            info_message(thing_name)
                            kwargs[thing_name] = getattr(file_import, thing_name)
                    #if thing_name not in basic_items:
                    #    kwargs_single_command[thing_name] = getattr(file_import, thing_name)
            #kwargs done
            if len(kwargs) > 0:
                #TODO: gotta find the right name and set it
                command_pool[file_import.__name__] = CommandSet(**kwargs)
            for function_name,function_object in kwargs_functions.items():
                new_command_set = CommandSet(**kwargs)
                setattr(new_command_set,function_name,function_object)
                command_pool[function_name] = new_command_set
            return command_pool

        except Exception as derp:
            self.error_exit('[-] CRITICAL ERROR: input file didnt validate, check your syntax maybe?', derp)

    ###################################################################################
    ## Dynamic imports
    ###################################################################################
    def dynamic_import(self, module_to_import, library_location = 'pybashy.command_set.'):
        '''
        Dynamically imports a module
            - used for the extensions

        Usage:
            thing = class.dynamic_import('name_of_file')
            returns a CommandSet()
        ''' 

        command_files_name     = library_location + module_to_import
        imported_file        = import_module(command_files_name)#, package='pybashy')
        command_pool_dict = self.get_functions(imported_file)
        return command_pool_dict
        #kwargs = self.get_functions(imported_file)
        #new_command_set = CommandSet(kwargs)
        #return new_command_set

###############################################################################
###############################################################################
#class Stepper:
#getattr, setattr and self.__dict__
#    '''
#Steps through the command
#    '''
