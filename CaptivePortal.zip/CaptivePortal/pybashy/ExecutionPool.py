# -*- coding: utf-8 -*-
################################################################################
##			debootstrapy - a linux tool for using debootstrap				  ##
################################################################################
# Copyright (c) 2020 Adam Galindo											  ##
#																			  ##
# Permission is hereby granted, free of charge, to any person obtaining a copy##
# of this software and associated documentation files (the "Software"),to deal##
# in the Software without restriction, including without limitation the rights##
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell   ##
# copies of the Software, and to permit persons to whom the Software is		  ##
# furnished to do so, subject to the following conditions:					  ##
#																			  ##
# Licenced under GPLv3														  ##
# https://www.gnu.org/licenses/gpl-3.0.en.html								  ##
#																			  ##
# The above copyright notice and this permission notice shall be included in  ##
# all copies or substantial portions of the Software.						  ##
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
####
################################################################################
"""


"""
__author__ 	= 'Adam Galindo'
__email__ 	= 'null@null.com'
__version__ = '1'
__license__ = 'GPLv3'

import os
import sys
import subprocess
from pybashy.Command import Command
from pybashy.useful_functions import greenprint,yellow_bold_print,redprint
from pybashy.useful_functions import info_message,warning_message,critical_message
from pybashy.useful_functions import error_message


class ExecutionPool():
    '''
    This is the command pool threading class, a container I guess?
    I dunno, I change things fast and loose
    Input : CommandSet()

    Operations:
        - turn "steps" into Command()
    '''
    def __init__(self, new_command_set):
        pool = {'test_init': Command({'test1' : ['ls -la ~/','info','pass','fail']})}
        #self.script_cwd               = Path().absolute()
        #self.script_osdir           = Path(__file__).parent.absolute()
        self.example  = {"ls_root" : ["ls -la /", "info", "[+] success message", "[-] failure message" ]}
        self.example2 = {"ls_etc"  : ["ls -la /etc"    ,'info', "[-] failure message", "[+] success message" ] ,
                           "ls_home" : ["ls -la ~/", 'info', "[-] failure message", "[+] success message" ]}


    def error_exit(self, message : str, derp : Exception):
        error_message(message = message)
        print(derp.with_traceback)
        sys.exit()    

    def step(self, dict_of_commands : dict):
        ''' performs a single exec_command() on an instruction in a set of steps

final step in the process of loading and executing a command from a module.
system exceptions/BASH interpreter exceptions come from here'''
        try:
            for instruction in dict_of_commands.values():
                cmd     = instruction[0]
                info    = instruction[1]
                success = instruction[2]
                fail     = instruction[3]
                yellow_bold_print(info)
                self.current_command = cmd
                cmd_exec = self.exec_command(self.current_command)
                if cmd_exec.returncode == 0 :
                    info_message(success)
                else:
                    error_message(fail)
        except Exception as derp:
            return derp
    
    def worker_bee(self, commandset_module , function_to_run = ''):
        '''
    Worker_bee() gathers up all the things to do and brings them to the stepper
    Dont run this function unless you want to run the scripts!
    
        - commandset_module is Required, performs all functions at once if 'func' parameter not given
        
        - function_to_run is the name of the function to run!
            only required if running in scripting mode
        '''
        try:
            #requesting a specific function_function
            if function_to_run != '':
                #filter out class stuff, we are searching for functions
                for thing in dir(commandset_module):
                    if thing.startswith('function') and thing.endswith(commandset_module):
                        self.success_message = getattr(thing,'success_message')
                        self.failure_message = getattr(thing,'failure_message')
                        self.info_message     = getattr(thing,'info_message')
                        self.steps             = getattr(thing,'steps')
                        stepper = self.step(self.steps)
                        if isinstance(stepper, Exception):
                            self.error_exit(self.failure_message, Exception)
                        else:
                            print(self.success_message)
            # the user wants to run all functions in the class
            else:
                pass
            # otherwise, everything is already assigned
            stepper = self.step(self.steps)
            if isinstance(stepper, Exception):
                print(stepper.error_message)
                raise stepper
            else:
                print(stepper.success_message)
        except Exception as derp:
            self.error_exit(self.failure_message, derp)

    def exec_command(self, command, blocking = True, shell_env = True):
        '''TODO: add formatting'''
        #read, write = os.pipe()
#        step = subprocess.Popen(something_to_set_env, 
#                        shell=shell_env, 
#                        stdin=read, 
#                        stdout=sys.stdout, 
#                        stderr=subprocess.PIPE)
#        Note that this is limited to sending a maximum of 64kB at a time,
#         pretty much an interactive session
#        byteswritten = os.write(write, str(command))

        try:
            if blocking == True:
                step = subprocess.Popen(command,
                                        shell=shell_env,
                                         stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE)
                output, error = step.communicate()
                for output_line in output.decode().split('\n'):
                    info_message(output_line)
                for error_lines in error.decode().split('\n'):
                    critical_message(error_lines)
                return step
            elif blocking == False:
                # TODO: not implemented yet                
                pass
        except Exception as derp:
            yellow_bold_print("[-] Shell Command failed!")
            return derp
    
    def threader(self, thread_function, name):
        info_message("Thread {}: starting".format(name))
        thread = threading.Thread(target=thread_function, args=(1,))
        thread.start()
        info_message("Thread {}: finishing".format(name))

    def add_attributes_kwargs(self, kwargs):
        for (k, v) in kwargs.items():
            setattr(self, k, v)
    
#    def new_command_set(self, command_set)
#        pass