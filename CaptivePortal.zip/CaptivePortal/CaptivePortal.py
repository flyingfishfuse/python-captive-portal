#!/usr/bin/python3
# -*- coding: utf-8 -*-
################################################################################
##   Captive portal thief/ rehosting daemon  -   python , flask , sqlalchemy  ##
################################################################################
# Copyright (c) 2020 Adam Galindo                                             ##
#                                                                             ##
# Permission is hereby granted, free of charge, to any person obtaining a copy##
# of this software and associated documentation files (the 'Software'),to deal##
# in the Software without restriction, including without limitation the rights##
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell   ##
# copies of the Software, and to permit persons to whom the Software is       ##
# furnished to do so, subject to the following conditions:                    ##
#                                                                             ##
# Licenced under GPLv3                                                        ##
# https://www.gnu.org/licenses/gpl-3.0.en.html                                ##
#                                                                             ##
# The above copyright notice and this permission notice shall be included in  ##
# all copies or substantial portions of the Software.                         ##
#
# THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
################################################################################

__author__  = 'Adam Galindo'
__email__   = 'null@null.com'
__version__ = '1'
__license__ = 'GPLv3'
__name__    = 'captive_portal using pybashy'

import os,sys
import argparse
import ipaddress
import configparser
from flask import Flask


from pybashy.CommandRunner import CommandRunner
from flask_database_backend import LoginInformation,ConnectedHosts,database
from pybashy.useful_functions import greenprint,redprint,blueprint,yellow_bold_print

parser = argparse.ArgumentParser(description='page mirroring tool utilizing wget via python scripting')
parser.add_argument('--PORTAL_IFACE',
                                 dest    = 'PORTAL_IFACE',
                                 action  = "store" ,
                                 default = "127.0.0.1" ,
                                 help    = "Website to mirror, this is usually the only option you should wset. Multiple downloads \
                                            will be stored in thier own directories, ready for hosting internally. " )
parser.add_argument('--CAPTIVE_PORTAL_IP',
                                 dest    = 'CAPTIVE_PORTAL_IP',
                                 action  = "store" ,
                                 default = "-nd -H -np -k -p -E" ,
                                 help    = "Wget options, Mirroring to a subdirectory is the default" )
parser.add_argument('--monitor_interface',
                                 dest    = 'useragent',
                                 action  = "store" ,
                                 default = 'Mozilla/5.0 (X11; Linux x86_64; rv:28.0) Gecko/20100101  Firefox/28.0' ,
                                 help    = "User agent to bypass crappy limitations" )
parser.add_argument('--manipulation_interface',
                                 dest    = '',
                                 action  = "store" ,
                                 default = '' ,
                                 help    = "" )
parser.add_argument('--FLASK_PORTAL_PAGE',
                                 dest    = '',
                                 action  = "store" ,
                                 default = '' ,
                                 help    = "" )
parser.add_argument('--FLASK_HOST_PORT',
                                 dest    = '',
                                 action  = "store" ,
                                 default = '' ,
                                 help    = "" )                                                                                                                                                                

#fucking skids
narf=True

FLASK_PORTAL_PAGE = '/login.php.html'
FLASK_HOST_PORT = 9090
PORTAL_IFACE = 'wlan2'
CAPTIVE_PORTAL_IP = '192.168.0.2'
monitor_interface = 'eth0'
manipulation_interface = 'eth1'

name_input = 'name'
email_input_name = 'email'
submit_form_name = 'submit'

class Portal():
    def __init__(self):
        pass

    def create_app(self):
        CaptivePortal = Flask(__name__)
        database.init_app(CaptivePortal)
        return CaptivePortal

# you must specify either config or arguments
if __name__ == "__main__":
#import the main file for the module.
    CommandRunner().dynamic_import('CaptivePortalCommands')
    arguments = parser.parse_args()
    #are we using config?
    if arguments.config_file == True:
        config = configparser.ConfigParser()
        config.read('captiveportal.config')
        # user needs to set config file or arguments
        if config['narf'] == True:
            yellow_bold_print("YOU HAVE TO CONFIGURE THE DARN THING FIRST!")
            raise SystemExit
            sys.exit()
        else:
            redprint("[-] Option not in config file")
    # not using config, parse the arguments and operate as if being used standalone
    elif arguments.config_file == False:
        thing_to_do = CommandRunner(arguments.blarp)